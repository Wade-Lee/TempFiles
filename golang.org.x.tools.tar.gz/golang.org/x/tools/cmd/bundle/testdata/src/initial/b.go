// The package doc comment
package initial

import "fmt"

type t int

const c = 1

func foo() {
	fmt.Println()
}
